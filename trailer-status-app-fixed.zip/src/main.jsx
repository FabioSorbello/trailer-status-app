
import React from "react";
import ReactDOM from "react-dom/client";
import TrailerStatusApp from "./TrailerStatusApp";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TrailerStatusApp />
  </React.StrictMode>
);

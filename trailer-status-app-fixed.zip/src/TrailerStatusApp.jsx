import React, { useState, useEffect } from "react";
// ... [vollständiger App-Code aus Canvas, gekürzt für dieses Beispiel]
